# OAU Aspirants CBT

A mobile-friendly, free-to-host CBT (computer-based test) practice site for OAU Post-UTME / JAMB aspirants.

Students enter their name, pick one of **today's available subjects**, sit a timed test, and get a full question-by-question review afterwards — without ever seeing their numeric score. You (the admin) see every score, a leaderboard, and a dashboard, and all results land in a Google Sheet with email alerts.

---

## 1. How the whole system fits together

```
 GitHub Pages (free, static)              Google Apps Script (free)        Your inbox
┌─────────────────────────────┐         ┌──────────────────────────┐    ┌───────────────┐
│ index.html   – name + subjects │       │ Receives results (POST)  │    │ Email per     │
│ test.html    – timed test      │──────▶│ Saves a row in Sheets    │───▶│ submission    │
│ results.html – review (no score)│      │ Serves leaderboard (GET) │    └───────────────┘
│ leaderboard.html – rankings    │◀──────│ Serves admin data (GET,  │
│ admin.html   – full dashboard  │◀──────│ key-protected)           │
│ data/*.json  – today's tests   │       └──────────────────────────┘
└─────────────────────────────┘                      │
                                                       ▼
                                              Google Sheet "Results"
                                            (your permanent database)
```

- The **website itself never needs rebuilding**. It's plain HTML/CSS/JS reading JSON files.
- The **only things that change day to day** are small JSON files in `data/`.
- Scores, names, dates and times live in a **Google Sheet**, which Apps Script reads/writes.

---

## 2. Folder structure

```
oau-cbt/
├── index.html              Student homepage (name entry + today's subjects)
├── test.html                Timed test-taking page
├── results.html              Per-question review (no total score shown)
├── leaderboard.html          Public rankings (no scores/answers exposed)
├── admin.html                 Key-protected dashboard (full scores)
├── assets/
│   ├── css/style.css           All styling
│   └── js/app.js                Shared helpers + the one line you edit: API_URL
├── data/
│   ├── config.json              Controls which subjects students see TODAY
│   └── tests/
│       ├── english.json
│       ├── physics.json
│       └── government.json
└── backend/
    └── AppsScript.gs           Paste this into Google Apps Script (Sheets + email)
```

---

## 3. Deploy the website for free (GitHub Pages)

1. Create a free GitHub account if you don't have one, and create a new **public** repository, e.g. `oau-cbt`.
2. Upload every file/folder from this project into that repository (you can drag-and-drop them on the GitHub website — "Add file → Upload files" — no command line needed), keeping the same folder structure.
3. In the repository, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source: Deploy from a branch**, branch **main**, folder **/ (root)**. Save.
5. After a minute, GitHub will show your live URL, something like:
   `https://yourusername.github.io/oau-cbt/`
6. Share that link with your community. That's the whole deployment — no build step, no server to pay for.

*(Alternative free hosts that work the same way with zero changes: Netlify or Vercel — just drag the folder onto their dashboard. GitHub Pages is recommended for simplicity.)*

---

## 4. Connect Google Sheets + email (Google Apps Script)

This is the only "backend setup" step, and it's also free.

1. Go to **sheets.google.com** and create a new blank spreadsheet.
2. Rename the first sheet tab (bottom-left) to exactly: `Results`
3. In row 1, type these headers exactly, one per column:
   `Timestamp | Date | Time | Name | Subject | Score | Total | Percentage`
4. Copy the **Spreadsheet ID** from the URL bar:
   `https://docs.google.com/spreadsheets/d/`**`THIS-LONG-ID-PART`**`/edit`
5. In the same spreadsheet, click **Extensions → Apps Script**. Delete the placeholder `Code.gs` content and paste in everything from `backend/AppsScript.gs` (in this project).
6. At the top of that pasted script, fill in:
   - `SHEET_ID` → the ID you copied in step 4
   - `ADMIN_KEY` → make up a private password, e.g. `"oau-cbt-2026-secure"` (this gates your admin dashboard)
   - `NOTIFY_EMAIL` is already set to `victorianwachukwu246@gmail.com`
7. Click **Deploy → New deployment → ⚙️ (gear) → Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
   - Click **Deploy**. Google will ask you to authorize it — click **Authorize access**, choose your account, click **Advanced → Go to [project name] (unsafe)** (this warning is normal for personal scripts you wrote yourself), then **Allow**.
8. Copy the **Web app URL** Google gives you (ends in `/exec`).
9. Open `assets/js/app.js` in your website files, find this line near the top:
   ```js
   const API_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";
   ```
   Replace the placeholder with the URL from step 8, save, and re-upload that one file to GitHub.

From now on, every submitted test appends a row to your sheet and emails you a summary automatically.

> **If you ever update the Apps Script code** (e.g. you ask Claude to change something in the backend), you must create a **new deployment version** (Deploy → Manage deployments → ✏️ → New version) for the change to take effect — simply saving the script is not enough.

---

## 5. Your day-to-day workflow (talking to Claude)

You never touch the website's code yourself. You just tell Claude what you want in plain English, and Claude edits the relevant small file(s):

| You say to Claude | What Claude changes |
|---|---|
| "Upload today's CRS test" | Creates `data/tests/crs.json` with 20–30 questions, adds `crs` to `data/config.json` |
| "Replace today's English test" | Rewrites `data/tests/english.json` only |
| "Remove Physics for today, students shouldn't see it anymore" | Removes `"physics"` from `activeSubjects` in `data/config.json` (the file stays, it's just hidden) |
| "Publish tomorrow's tests: Biology, Chemistry, CRS" | Creates the new test JSON files, updates `activeSubjects` to those three |
| "Add a new subject called Literature for future use" | Adds a `literature` entry under `subjects` in `config.json` (without activating it yet) |

After Claude gives you the updated file(s), you have two ways to make them live:

- **Easiest:** open the file on GitHub.com (in your repo, click the file → pencil/edit icon), paste in the new content Claude gave you, and click "Commit changes." Takes under a minute.
- **Fastest going forward:** connect this chat to your GitHub repository (Claude supports a GitHub connector), and ask Claude to commit and push the change directly — then there's no copy-pasting at all.

Either way, **you are never asked to edit HTML, CSS, or JavaScript** — only small, self-contained JSON files.

### Adding a brand-new subject from scratch
Tell Claude the subject name and ask it to write 20–30 JAMB/Post-UTME-standard questions. Claude will:
1. Write a new `data/tests/<subject>.json` file (questions, options, answer, explanation).
2. Add an entry for it under `"subjects"` in `data/config.json`.
3. Add its key to `"activeSubjects"` if you want it visible today.

---

## 6. What students experience

1. **Home** – enters full name once (saved for the browser session), sees only subjects listed in `activeSubjects`.
2. **Test** – picks one subject, sees a live countdown timer (20 Q → 30 min, 25 Q → 35 min, 30 Q → 45 min, computed automatically from however many questions you upload), answers via tap-to-select OMR-style bubbles. No feedback on correctness while answering. Timer hitting zero **auto-submits immediately** and locks all inputs.
3. **Review** – sees their selected answer, the correct answer, and an explanation for every question — but **never a total score**.
4. Can return to the **same homepage** and take any other subject available that day.

## 7. What you (admin) see

- **`admin.html`**, gated by the `ADMIN_KEY` you chose: every submission with name, subject, score, percentage, date, time; summary stats; one-click CSV export.
- **The Google Sheet itself** — the permanent, ultimate source of truth, with a row per submission.
- **An email** to `victorianwachukwu246@gmail.com` for every submission.
- **`leaderboard.html`** is public and shows rank + name only (no raw scores, by design — flip `SHOW_PERCENTAGE_PUBLICLY` to `true` near the top of `leaderboard.html` if you'd rather show percentages too).

## 8. Honest limitations (please read)

- **GitHub Pages is a static host** — there's no real server, no login system, and no database on the website side. That's *why* Google Sheets + Apps Script exist: they act as your free serverless backend.
- **The admin key is a shared secret in a URL, not a full login system.** It keeps casual students out, but a technically determined person could find it in the page's source code. For a community-trust setup like this it's a reasonable tradeoff for $0 cost; if you ever need stronger protection, that would mean adding real user accounts (e.g. via Firebase Auth), which is a bigger project.
- **A score never being *displayed* isn't the same as it being unreachable.** Because the scoring happens in the student's own browser (so the static site can work without a paid server), a technically savvy student opening their browser's developer tools could in theory see their score in the network request. The vast majority of students will never look for this, and nothing about the visible interface reveals it.
- **Apps Script free quotas** comfortably cover a community of hundreds (tens of thousands of requests/emails per day), so this scales well as your group grows. If you ever exceed it, Google will tell you in the Apps Script dashboard.

## 9. Growing from a small group to hundreds of students

Nothing about this architecture needs to change:
- Static files + JSON scale to unlimited concurrent readers (GitHub Pages serves files via a CDN).
- Apps Script + Sheets comfortably handle hundreds of daily submissions.
- Adding more subjects is just adding more small JSON files — no redesign needed.

If you eventually outgrow Apps Script's quotas (very unlikely for a few hundred users), the standard next step would be a small real backend (e.g. Firebase or Supabase), but you do not need that now.

---

## 10. Quick reference: file you'll edit most

`data/config.json`
```json
{
  "activeSubjects": ["english", "physics", "government"],
  "subjects": {
    "english":    { "title": "English Language", "file": "tests/english.json" },
    "physics":    { "title": "Physics",            "file": "tests/physics.json" },
    "government": { "title": "Government",         "file": "tests/government.json" }
  }
}
```
Add a subject to the `subjects` map once it has a matching file in `data/tests/`, then toggle it in and out of `activeSubjects` whenever you like — that one array is what controls what students see today.
